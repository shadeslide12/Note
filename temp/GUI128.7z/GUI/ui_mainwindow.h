/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QPushButton *pushButton;
    QPushButton *pushButton_3;
    QLabel *label_WorkDir;
    QLineEdit *lE_ShowDir;
    QPushButton *Btn_ChooseDir;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(800, 294);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(100, 60, 201, 101));
        pushButton_3 = new QPushButton(centralwidget);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(399, 60, 241, 101));
        label_WorkDir = new QLabel(centralwidget);
        label_WorkDir->setObjectName(QString::fromUtf8("label_WorkDir"));
        label_WorkDir->setGeometry(QRect(110, 210, 131, 16));
        lE_ShowDir = new QLineEdit(centralwidget);
        lE_ShowDir->setObjectName(QString::fromUtf8("lE_ShowDir"));
        lE_ShowDir->setGeometry(QRect(270, 210, 241, 21));
        lE_ShowDir->setReadOnly(true);
        Btn_ChooseDir = new QPushButton(centralwidget);
        Btn_ChooseDir->setObjectName(QString::fromUtf8("Btn_ChooseDir"));
        Btn_ChooseDir->setGeometry(QRect(550, 210, 51, 23));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 20));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "Preprocessor", nullptr));
        pushButton_3->setText(QCoreApplication::translate("MainWindow", "Post", nullptr));
        label_WorkDir->setText(QCoreApplication::translate("MainWindow", "Working Directory :", nullptr));
        Btn_ChooseDir->setText(QCoreApplication::translate("MainWindow", "....", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
