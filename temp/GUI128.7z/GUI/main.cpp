#include "mainwindow.h"
#include <QSurface>
#include "QVTKOpenGLNativeWidget.h"

#include <QApplication>
#include <QDir>

int main(int argc, char *argv[])
{
    QSurfaceFormat::setDefaultFormat(QVTKOpenGLNativeWidget::defaultFormat());
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();
}
