#include "ControlPanel.h"
#include "ui_ControlPanel.h"
#include <iostream>
#include <algorithm>
#include <QSet>

ControlPanel::ControlPanel(QWidget *parent): QDialog(parent),ui(new Ui::ControlPanel) {
    ui->setupUi(this);
    
    // 启用表格多选功能
    ui->dataTable->setSelectionMode(QAbstractItemView::ExtendedSelection);
    ui->dataTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    
    // 为表格 viewport 安装事件过滤器，用于捕获控件上的右键事件
    ui->dataTable->viewport()->installEventFilter(this);
    
    // 启用右键菜单（保留，用于前三列的 QTableWidgetItem）
    ui->dataTable->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ui->dataTable, &QTableWidget::customContextMenuRequested,
            this, &ControlPanel::showTransparencyContextMenu);
    
    // 连接全局透明度按钮（保留旧功能）
    connect(ui->btnApplyGlobalTransparency, &QPushButton::clicked, 
            this, &ControlPanel::onApplyGlobalTransparency);
}

ControlPanel::~ControlPanel() {
    delete ui;
}

void ControlPanel::setupTable(std::vector<std::vector<vtkAesReader::Boundary>> boundarys)
{   
    ui->dataTable->setColumnWidth(0, 70);   
    ui->dataTable->setColumnWidth(1, 200);  
    ui->dataTable->setColumnWidth(2, 120);   
    ui->dataTable->setColumnWidth(3, 70);   
    ui->dataTable->setColumnWidth(4, 100);   
    ui->dataTable->setColumnWidth(5, 100);   
    ui->dataTable->setColumnWidth(6, 100);   

    //* 收集所有的boundary信息
    QStringList zoneNumbers;
    QStringList boundaryNames;
    
    int boundaryCount = 0;
    
    // 清空之前的索引信息
    boundaryIndices.clear();
    cutplaneInfos.clear();
    rowTypes.clear();
    
    for (int i = 0; i < boundarys.size(); i++) {
        for (int j = 0; j < boundarys[i].size(); j++) {
            boundaryCount++;
            
            zoneNumbers.append(QString("%1*").arg(boundaryCount));
            
            QString zoneName = QString(boundarys[i][j].zoneName.c_str()).trimmed();
            QString boundaryName = QString(boundarys[i][j].name.c_str()).trimmed();
            
            // 创建zone->boundary格式的名称
            QString combinedName = QString("%1->%2").arg(zoneName).arg(boundaryName);

            boundaryNames.append(combinedName);
            
            // 存储boundary索引信息
            boundaryIndices.push_back(std::make_pair(i, j));
            rowTypes.push_back(BOUNDARY);
        }
    }
    
    // 设置表格行数为实际的boundary数量
    ui->dataTable->setRowCount(boundaryCount);
    
    // 填充表格
    for (int row = 0; row < boundaryCount; ++row) {
        //* Set Zone Number
        QTableWidgetItem* zoneNumItem = new QTableWidgetItem(zoneNumbers[row]);
        zoneNumItem->setTextAlignment(Qt::AlignCenter);
        ui->dataTable->setItem(row, 0, zoneNumItem);
        
        //* Set Zone Name 
        QTableWidgetItem* zoneNameItem = new QTableWidgetItem(boundaryNames[row]);
        ui->dataTable->setItem(row, 1, zoneNameItem);
        
        //* Set Group Number
        QTableWidgetItem* groupNumItem = new QTableWidgetItem("Main Model");
        groupNumItem->setTextAlignment(Qt::AlignCenter);
        ui->dataTable->setItem(row, 2, groupNumItem);
        
        QWidget* checkBoxWidget = createCheckBoxWidget(true);
        QCheckBox* checkBox = checkBoxWidget->findChild<QCheckBox*>();
        if (checkBox) {
            // 设置复选框的属性，用于识别对应的boundary
            checkBox->setProperty("boundaryRow", row);
            connect(checkBox, &QCheckBox::toggled, this, &ControlPanel::onShowZoneCheckBoxToggled);
        }
        ui->dataTable->setCellWidget(row, 3, checkBoxWidget);
        
        //* Set Contour Mode 
        ui->dataTable->setCellWidget(row, 4, createComboBoxWidget());
        
        //* Set Transparency - 为boundary行创建透明度控件
        QWidget* transparencyWidget = createTransparencyWidget(0.5);
        QDoubleSpinBox* transSpinBox = transparencyWidget->findChild<QDoubleSpinBox*>();
        if (transSpinBox) {
            // 设置属性，用于识别对应的boundary
            transSpinBox->setProperty("boundaryRow", row);
            connect(transSpinBox, QOverload<double>::of(&QDoubleSpinBox::valueChanged), 
                    this, &ControlPanel::onBoundaryTransparencyChanged);
        }
        ui->dataTable->setCellWidget(row, 5, transparencyWidget);
        
        //* Set Delete Button
        ui->dataTable->setCellWidget(row, 6, createDeleteButtonWidget());
    }
}

QWidget* ControlPanel::createCheckBoxWidget(bool checked)
{
    QWidget* widget = new QWidget();
    QHBoxLayout* layout = new QHBoxLayout(widget);
    QCheckBox* checkBox = new QCheckBox();
    checkBox->setChecked(checked);
    
    layout->addWidget(checkBox);
    layout->setAlignment(Qt::AlignCenter);
    layout->setContentsMargins(0, 0, 0, 0);
    
    return widget;
}

QWidget* ControlPanel::createComboBoxWidget()
{
    QWidget* widget = new QWidget();
    QHBoxLayout* layout = new QHBoxLayout(widget);
    QComboBox* comboBox = new QComboBox();
    
    comboBox->addItem("isolated");
    comboBox->addItem("sync with main");
    comboBox->setCurrentIndex(0);
    
    layout->addWidget(comboBox);
    layout->setAlignment(Qt::AlignCenter);
    layout->setContentsMargins(0, 0, 0, 0);
    
    return widget;
}

QWidget* ControlPanel::createTransparencyWidget(double value)
{
    QWidget* widget = new QWidget();
    QHBoxLayout* layout = new QHBoxLayout(widget);
    QDoubleSpinBox* spinBox = new QDoubleSpinBox();
    
    spinBox->setRange(0.0, 1.0);
    spinBox->setSingleStep(0.1);
    spinBox->setValue(value);
    spinBox->setDecimals(1);
    
    layout->addWidget(spinBox);
    layout->setAlignment(Qt::AlignCenter);
    layout->setContentsMargins(0, 0, 0, 0);
    
    return widget;
}

QWidget* ControlPanel::createDeleteButtonWidget()
{
    QWidget* widget = new QWidget();
    QHBoxLayout* layout = new QHBoxLayout(widget);
    QPushButton* deleteButton = new QPushButton("Delete");
    
    layout->addWidget(deleteButton);
    layout->setAlignment(Qt::AlignCenter);
    layout->setContentsMargins(0, 0, 0, 0);
    
    return widget;
}

void ControlPanel::onShowZoneCheckBoxToggled(bool checked)
{
    // 获取发送信号的复选框
    QCheckBox* checkBox = qobject_cast<QCheckBox*>(sender());
    if (!checkBox) return;
    
    // 获取对应的行号
    int    row = checkBox->property("boundaryRow").toInt();
    
     // 检查行号是否有效
    if (row < 0 || row >= rowTypes.size()) return;
    
    // 根据行类型发送不同的信号
    if (rowTypes[row] == BOUNDARY) {
        // 处理boundary
        if (row >= boundaryIndices.size()) return;
        
        int meshNumber = boundaryIndices[row].first;
        int boundaryNumber = boundaryIndices[row].second;
        
        // 发送信号控制boundary可见性
        emit setBoundarys(meshNumber, boundaryNumber, checked);
    }
    else if (rowTypes[row] == CUTPLANE) {
        // 处理cutplane
        int cutplaneIndex = row - boundaryIndices.size(); // cutplane在boundary之后
        if (cutplaneIndex < 0 || cutplaneIndex >= cutplaneInfos.size()) return;
        
        int cutplaneNumber = cutplaneInfos[cutplaneIndex].index;
        
        // 发送信号控制cutplane可见性
        emit setCutplaneVisiable(cutplaneNumber, checked);
    }
}

void ControlPanel::addCutplaneToTable(int cutplaneIndex, double* origin, double* normal)
{
    // 存储cutplane信息
    CutplaneInfo cutplaneInfo;
    cutplaneInfo.index = cutplaneIndex;
    for (int i = 0; i < 3; i++) {
        cutplaneInfo.origin[i] = origin[i];
        cutplaneInfo.normal[i] = normal[i];
    }
    cutplaneInfos.push_back(cutplaneInfo);
    
    // 获取当前行数
    int currentRowCount = ui->dataTable->rowCount();
    int newRow = currentRowCount;
    
    // 增加一行
    ui->dataTable->setRowCount(currentRowCount + 1);
    rowTypes.push_back(CUTPLANE);
    
    // 填充cutplane行数据
    //* Set Zone Number
    QString cutplaneNumber = QString("S%1*").arg(cutplaneIndex + 1);
    QTableWidgetItem* zoneNumItem = new QTableWidgetItem(cutplaneNumber);
    zoneNumItem->setTextAlignment(Qt::AlignCenter);
    ui->dataTable->setItem(newRow, 0, zoneNumItem);
    
    //* Set Zone Name (cutplane信息)
    QString cutplaneName = QString("Slice_%1").arg(cutplaneIndex + 1);
    QTableWidgetItem* zoneNameItem = new QTableWidgetItem(cutplaneName);
    ui->dataTable->setItem(newRow, 1, zoneNameItem);
    
    //* Set Group Type
    QTableWidgetItem* groupNumItem = new QTableWidgetItem("Slice");
    groupNumItem->setTextAlignment(Qt::AlignCenter);
    ui->dataTable->setItem(newRow, 2, groupNumItem);
    
    //* Set Show Zone checkbox
    QWidget* checkBoxWidget = createCheckBoxWidget(true);
    QCheckBox* checkBox = checkBoxWidget->findChild<QCheckBox*>();
    if (checkBox) {
        checkBox->setProperty("boundaryRow", newRow);
        connect(checkBox, &QCheckBox::toggled, this, &ControlPanel::onShowZoneCheckBoxToggled);
    }
    ui->dataTable->setCellWidget(newRow, 3, checkBoxWidget);
    
    //* Set Contour Mode - 只为slice行连接响应函数
    QWidget* comboWidget = createComboBoxWidget();
    QComboBox* comboBox = comboWidget->findChild<QComboBox*>();
    if (comboBox) {
        // 设置属性，用于识别对应的cutplane
        comboBox->setProperty("cutplaneIndex", cutplaneIndex);
        connect(comboBox, QOverload<const QString &>::of(&QComboBox::currentTextChanged), 
                this, &ControlPanel::onSliceContourModeChanged);
    }
    ui->dataTable->setCellWidget(newRow, 4, comboWidget);
    
    //* Set Transparency - 为slice行创建透明度控件
    QWidget* transparencyWidget = createTransparencyWidget(1.0);
    QDoubleSpinBox* transSpinBox = transparencyWidget->findChild<QDoubleSpinBox*>();
    if (transSpinBox) {
        // 设置属性，用于识别对应的slice
        transSpinBox->setProperty("sliceIndex", cutplaneIndex);
        connect(transSpinBox, QOverload<double>::of(&QDoubleSpinBox::valueChanged), 
                this, &ControlPanel::onSliceTransparencyChanged);
    }
    ui->dataTable->setCellWidget(newRow, 5, transparencyWidget);
    
    //* Set Delete Button - 只为slice行连接删除功能
    QWidget* deleteWidget = createDeleteButtonWidget();
    QPushButton* deleteButton = deleteWidget->findChild<QPushButton*>();
    if (deleteButton) {
        // 设置按钮属性，用于识别对应的cutplane
        deleteButton->setProperty("cutplaneIndex", cutplaneIndex);
        connect(deleteButton, &QPushButton::clicked, this, &ControlPanel::onSliceDeleteClicked);
    }
    ui->dataTable->setCellWidget(newRow, 6, deleteWidget);
}

void ControlPanel::onBoundaryTransparencyChanged(double value)
{
    // 获取发送信号的SpinBox
    QDoubleSpinBox* spinBox = qobject_cast<QDoubleSpinBox*>(sender());
    if (!spinBox) return;
    
    // 获取对应的行号
    int row = spinBox->property("boundaryRow").toInt();
    
    // 检查行号是否有效
    if (row < 0 || row >= boundaryIndices.size()) return;
    
    int meshNumber = boundaryIndices[row].first;
    int boundaryNumber = boundaryIndices[row].second;
    
    // 发送boundary透明度变化信号
    emit boundaryTransparencyChanged(meshNumber, boundaryNumber, value);
    
    std::cout << "[Debug] Boundary transparency changed: mesh=" << meshNumber 
              << ", boundary=" << boundaryNumber << ", value=" << value << std::endl;
}

void ControlPanel::onSliceTransparencyChanged(double value)
{
    // 获取发送信号的SpinBox
    QDoubleSpinBox* spinBox = qobject_cast<QDoubleSpinBox*>(sender());
    if (!spinBox) return;
    
    // 获取对应的slice索引
    int sliceIndex = spinBox->property("sliceIndex").toInt();
    
    // 发送slice透明度变化信号
    emit sliceTransparencyChanged(sliceIndex, value);
    
    std::cout << "[Debug] Slice transparency changed: slice=" << sliceIndex 
              << ", value=" << value << std::endl;
}

void ControlPanel::setTransparencyControlsEnabled(bool enabled)
{
    // 遍历所有行，启用/禁用Transparency列的控件
    for (int row = 0; row < ui->dataTable->rowCount(); row++) {
        QWidget* transparencyWidget = ui->dataTable->cellWidget(row, 5); // Transparency列是第5列
        if (transparencyWidget) {
            QDoubleSpinBox* spinBox = transparencyWidget->findChild<QDoubleSpinBox*>();
            if (spinBox) {
                spinBox->setEnabled(enabled);
            }
        }
    }
    
    std::cout << "[Debug] Transparency controls enabled: " << (enabled ? "true" : "false") << std::endl;
}

void ControlPanel::onSliceDeleteClicked()
{
    // 获取发送信号的按钮
    QPushButton* button = qobject_cast<QPushButton*>(sender());
    if (!button) return;
    
    // 获取对应的cutplane索引
    int cutplaneIndex = button->property("cutplaneIndex").toInt();
    
    // 发送删除请求信号
    emit sliceDeleteRequested(cutplaneIndex);
    
    // 从ControlPanel表格中删除对应行
    removeCutplaneFromTable(cutplaneIndex);
}

void ControlPanel::removeCutplaneFromTable(int cutplaneIndex)
{
    // 找到对应的行号
    int rowToRemove = -1;
    int cutplaneCount = 0;
    
    for (int i = 0; i < rowTypes.size(); i++) {
        if (rowTypes[i] == CUTPLANE) {
            if (cutplaneInfos[cutplaneCount].index == cutplaneIndex) {
                rowToRemove = i;
                break;
            }
            cutplaneCount++;
        }
    }
    
    // 如果找到对应的行，则删除
    if (rowToRemove != -1) {
        // 从表格中删除行
        ui->dataTable->removeRow(rowToRemove);
        
        // 从rowTypes中删除对应项
        rowTypes.erase(rowTypes.begin() + rowToRemove);
        
        // 从cutplaneInfos中删除对应项
        int cutplaneInfoIndex = rowToRemove - boundaryIndices.size();
        if (cutplaneInfoIndex >= 0 && cutplaneInfoIndex < cutplaneInfos.size()) {
            cutplaneInfos.erase(cutplaneInfos.begin() + cutplaneInfoIndex);
        }
        
        // 更新后续cutplane行的索引和显示名称
        int newCutplaneNumber = 1; // 重新编号从1开始
        for (int i = 0; i < rowTypes.size(); i++) {
            if (rowTypes[i] == CUTPLANE) {
                int currentCutplaneInfoIndex = i - boundaryIndices.size();
                if (currentCutplaneInfoIndex >= 0 && currentCutplaneInfoIndex < cutplaneInfos.size()) {
                    // 更新cutplaneInfo中的索引
                    cutplaneInfos[currentCutplaneInfoIndex].index = newCutplaneNumber - 1; // 内部索引从0开始
                    
                    // 更新Zone Number (S1*, S2*, S3*...)
                    QString newZoneNumber = QString("S%1*").arg(newCutplaneNumber);
                    QTableWidgetItem* zoneNumberItem = ui->dataTable->item(i, 0);
                    if (zoneNumberItem) {
                        zoneNumberItem->setText(newZoneNumber);
                    }
                    
                    // 更新Zone Name (Slice_1, Slice_2, Slice_3...)
                    QString newZoneName = QString("Slice_%1").arg(newCutplaneNumber);
                    QTableWidgetItem* zoneNameItem = ui->dataTable->item(i, 1);
                    if (zoneNameItem) {
                        zoneNameItem->setText(newZoneName);
                    }
                    
                    newCutplaneNumber++;
                }
            }
        }
    }
}

void ControlPanel::onSliceContourModeChanged(const QString &text)
{
    // 获取发送信号的下拉框
    QComboBox* comboBox = qobject_cast<QComboBox*>(sender());
    if (!comboBox) return;
    
    // 获取对应的cutplane索引
    int cutplaneIndex = comboBox->property("cutplaneIndex").toInt();
    
    // 输出调试信息
    std::cout << "[Debug] Slice " << cutplaneIndex + 1 << " contour mode changed to: " << text.toStdString() << std::endl;
    
    // 发送contour mode变化信号
    emit sliceContourModeChanged(text);
    
    // 同步更新其他slice行的contour mode
    syncSliceContourMode(text, cutplaneIndex);
}

void ControlPanel::syncSliceContourMode(const QString &text, int excludeCutplaneIndex)
{
    // 遍历所有行，找到slice行
    for (int i = 0; i < rowTypes.size(); i++) {
        if (rowTypes[i] == CUTPLANE) {
            // 计算当前slice的cutplaneIndex
            int currentCutplaneInfoIndex = i - boundaryIndices.size();
            if (currentCutplaneInfoIndex >= 0 && currentCutplaneInfoIndex < cutplaneInfos.size()) {
                int currentCutplaneIndex = cutplaneInfos[currentCutplaneInfoIndex].index;
                
                // 跳过触发变化的slice
                if (currentCutplaneIndex == excludeCutplaneIndex) continue;
                
                // 获取对应的下拉框
                QWidget* comboWidget = ui->dataTable->cellWidget(i, 4);
                if (comboWidget) {
                    QComboBox* comboBox = comboWidget->findChild<QComboBox*>();
                    if (comboBox) {
                        // 临时阻塞信号，避免触发响应函数
                        comboBox->blockSignals(true);
                        comboBox->setCurrentText(text);
                        comboBox->blockSignals(false);
                        
                        std::cout << "[Debug] Synced Slice " << currentCutplaneIndex + 1 
                                  << " contour mode to: " << text.toStdString() << std::endl;
                    }
                }
            }
        }
    }
}

void ControlPanel::onApplyGlobalTransparency()
{
    double globalValue = ui->spinGlobalTransparency->value();
    
    std::cout << "[Debug] Applying global transparency: " << globalValue << std::endl;
    
    // 遍历所有boundary行，设置透明度
    for (int row = 0; row < rowTypes.size(); row++) {
        if (rowTypes[row] == BOUNDARY) {
            QWidget* transparencyWidget = ui->dataTable->cellWidget(row, 5);
            if (transparencyWidget) {
                QDoubleSpinBox* spinBox = transparencyWidget->findChild<QDoubleSpinBox*>();
                if (spinBox) {
                    // 临时阻塞信号，避免每次修改都触发信号
                    spinBox->blockSignals(true);
                    spinBox->setValue(globalValue);
                    spinBox->blockSignals(false);
                    
                    // 手动发送信号更新对应的boundary
                    int meshNumber = boundaryIndices[row].first;
                    int boundaryNumber = boundaryIndices[row].second;
                    emit boundaryTransparencyChanged(meshNumber, boundaryNumber, globalValue);
                }
            }
        }
    }
    
    std::cout << "[Debug] Global transparency applied to all boundaries" << std::endl;
}

void ControlPanel::getAllBoundaryTransparencies(std::vector<std::vector<double>>& transparencies)
{
    // 清空输出向量
    transparencies.clear();
    
    // 根据boundaryIndices的结构初始化transparencies
    if (boundaryIndices.empty()) return;
    
    // 找出最大的mesh索引
    int maxMeshIndex = 0;
    for (const auto& pair : boundaryIndices) {
        if (pair.first > maxMeshIndex) {
            maxMeshIndex = pair.first;
        }
    }
    
    // 初始化transparencies向量
    transparencies.resize(maxMeshIndex + 1);
    
    // 遍历所有boundary行，获取透明度值
    for (int row = 0; row < rowTypes.size(); row++) {
        if (rowTypes[row] == BOUNDARY && row < boundaryIndices.size()) {
            int meshNumber = boundaryIndices[row].first;
            int boundaryNumber = boundaryIndices[row].second;
            
            // 确保transparencies[meshNumber]有足够的空间
            if (transparencies[meshNumber].size() <= boundaryNumber) {
                transparencies[meshNumber].resize(boundaryNumber + 1, 1.0);
            }
            
            // 获取透明度值
            QWidget* transparencyWidget = ui->dataTable->cellWidget(row, 5);
            if (transparencyWidget) {
                QDoubleSpinBox* spinBox = transparencyWidget->findChild<QDoubleSpinBox*>();
                if (spinBox) {
                    transparencies[meshNumber][boundaryNumber] = spinBox->value();
                }
            }
        }
    }
}

void ControlPanel::setAllBoundaryTransparencies(const std::vector<std::vector<double>>& transparencies)
{
    // 遍历所有boundary行，设置透明度值
    for (int row = 0; row < rowTypes.size(); row++) {
        if (rowTypes[row] == BOUNDARY && row < boundaryIndices.size()) {
            int meshNumber = boundaryIndices[row].first;
            int boundaryNumber = boundaryIndices[row].second;
            
            // 检查索引有效性
            if (meshNumber >= transparencies.size() || 
                boundaryNumber >= transparencies[meshNumber].size()) {
                continue;
            }
            
            double value = transparencies[meshNumber][boundaryNumber];
            
            // 设置UI控件的值
            QWidget* transparencyWidget = ui->dataTable->cellWidget(row, 5);
            if (transparencyWidget) {
                QDoubleSpinBox* spinBox = transparencyWidget->findChild<QDoubleSpinBox*>();
                if (spinBox) {
                    spinBox->blockSignals(true);
                    spinBox->setValue(value);
                    spinBox->blockSignals(false);
                }
            }
        }
    }
}

void ControlPanel::showTransparencyContextMenu(const QPoint& pos)
{
    // 1. 获取点击的单元格，检查是否在第5列（Transculency列）
    QTableWidgetItem* item = ui->dataTable->itemAt(pos);
    if (item) {
        int column = item->column();
        if (column != 5) {
            return;  // 不在第5列，不显示菜单
        }
    }
    
    // 2. 检查是否有选中的行
    QList<int> selectedRows = getSelectedRows();
    if (selectedRows.isEmpty()) return;
    
    // 3. 创建右键菜单
    QMenu* menu = new QMenu(this);
    menu->setStyleSheet(
        "QMenu { background-color: white; border: 1px solid #ccc; }"
        "QMenu::item { padding: 5px 30px 5px 20px; }"
        "QMenu::item:selected { background-color: #0078d4; color: white; }"
    );
    
    // 添加预设值选项
    QAction* action0 = menu->addAction("0 (Transparent)");
    QAction* action20 = menu->addAction("20");
    QAction* action40 = menu->addAction("40");
    QAction* action60 = menu->addAction("60");
    QAction* action80 = menu->addAction("80");
    QAction* action100 = menu->addAction("100 (Opaque)");
    
    menu->addSeparator();
    
    // 添加自定义输入选项
    QAction* actionCustom = menu->addAction("Enter...");
    
    // 4. 显示菜单并处理选择
    QAction* selectedAction = menu->exec(ui->dataTable->viewport()->mapToGlobal(pos));
    
    if (selectedAction == action0) {
        applyTransparencyToSelected(0.0);
    } else if (selectedAction == action20) {
        applyTransparencyToSelected(0.2);
    } else if (selectedAction == action40) {
        applyTransparencyToSelected(0.4);
    } else if (selectedAction == action60) {
        applyTransparencyToSelected(0.6);
    } else if (selectedAction == action80) {
        applyTransparencyToSelected(0.8);
    } else if (selectedAction == action100) {
        applyTransparencyToSelected(1.0);
    } else if (selectedAction == actionCustom) {
        showCustomTransparencyDialog();
    }
    
    delete menu;
}

QList<int> ControlPanel::getSelectedRows()
{
    QList<int> selectedRows;
    QList<QTableWidgetItem*> selectedItems = ui->dataTable->selectedItems();
    
    // 去重，只保留行号
    QSet<int> rowSet;
    for (QTableWidgetItem* item : selectedItems) {
        rowSet.insert(item->row());
    }
    
    selectedRows = rowSet.values();
    std::sort(selectedRows.begin(), selectedRows.end());
    
    return selectedRows;
}

void ControlPanel::applyTransparencyToSelected(double value)
{
    QList<int> selectedRows = getSelectedRows();
    
    std::cout << "[Debug] Applying transparency " << value 
              << " to " << selectedRows.size() << " selected rows" << std::endl;
    
    for (int row : selectedRows) {
        // 检查行类型（只处理 BOUNDARY 行）
        if (row >= rowTypes.size() || rowTypes[row] != BOUNDARY) {
            std::cout << "[Debug] Skipping row " << row << " (not a boundary)" << std::endl;
            continue;
        }
        
        // 获取该行的透明度 SpinBox
        QWidget* transparencyWidget = ui->dataTable->cellWidget(row, 5);
        if (!transparencyWidget) continue;
        
        QDoubleSpinBox* spinBox = transparencyWidget->findChild<QDoubleSpinBox*>();
        if (!spinBox) continue;
        
        // 设置新的透明度值
        spinBox->blockSignals(true);
        spinBox->setValue(value);
        spinBox->blockSignals(false);
        
        // 手动发送信号更新 VTK 渲染
        if (row < boundaryIndices.size()) {
            int meshNumber = boundaryIndices[row].first;
            int boundaryNumber = boundaryIndices[row].second;
            emit boundaryTransparencyChanged(meshNumber, boundaryNumber, value);
            
            std::cout << "[Debug] Set boundary [" << meshNumber << "][" << boundaryNumber 
                      << "] transparency to " << value << std::endl;
        }
    }
}

void ControlPanel::showCustomTransparencyDialog()
{
    bool ok;
    double value = QInputDialog::getDouble(
        this,
        "Set Transparency",
        "Enter transparency value (0-100):\n0 = Transparent, 100 = Opaque",
        50.0,      // 默认值
        0.0,       // 最小值
        100.0,     // 最大值
        1,         // 小数位数
        &ok
    );
    
    if (ok) {
        // 将 0-100 转换为 0.0-1.0
        applyTransparencyToSelected(value / 100.0);
    }
}

bool ControlPanel::eventFilter(QObject* obj, QEvent* event)
{
    // 检查是否是表格 viewport 的右键菜单事件
    if (obj == ui->dataTable->viewport() && event->type() == QEvent::ContextMenu) {
        QContextMenuEvent* contextEvent = static_cast<QContextMenuEvent*>(event);
        
        // 获取点击位置对应的单元格
        QPoint pos = contextEvent->pos();
        int row = ui->dataTable->rowAt(pos.y());
        int col = ui->dataTable->columnAt(pos.x());
        
        // 只在第5列（Transculency列）显示透明度菜单
        if (col == 5 && row >= 0) {
            // 检查是否有选中的行
            QList<int> selectedRows = getSelectedRows();
            if (!selectedRows.isEmpty()) {
                // 显示透明度右键菜单
                showTransparencyContextMenu(pos);
                return true;  // 事件已处理
            }
        }
        
        // 其他列的右键事件可以在这里添加处理
        // 例如：
        // if (col == 3) { /* Show Zone 列的菜单 */ }
        // if (col == 4) { /* Contour Mode 列的菜单 */ }
        // if (col == 6) { /* Delete 列的菜单 */ }
    }
    
    // 其他事件传递给基类处理
    return QDialog::eventFilter(obj, event);
}
